# V4-CORE-RUNTIME-RECOVERY C2 实施报告

Commit: 52d58703beac70eecb4dc338f84969cf275c87b1
Scope: C2 actual implementation only; NOT T1 DONE. No push/merge/MR/nested agents. Worktree clean after commit. Parent task-card amendment authorized event_test.go:329 srcA.ResourceVersion only.

## 做了什么
- 单一 opaque ResourceVersion(uid,revision) helper rv1:UID:revision；所有 public name CAS 在同一 BEGIN IMMEDIATE 事务中绑定 namespace/name/live/UID/revision；缺失 required、格式 invalid、冲突携带 CurrentResourceVersion 完整 token。
- Capability next/displayName CAS 同次更新一份 revision，保持 digest/content version；Create read-only reuse，不再无 CAS 改 mutable 字段。移除无效 Force compatibility wrapper。
- 内部 deleted_at + 两个 live-only unique keys；公开 resolve/list/versions/fold/artifact/deploy 过滤 tombstone。逻辑删除仅 own outgoing projection，incoming refs 保留。Task private pinned UID reader/真实 deployment delivery 保留旧正文；同名同版同digest重建新UID，现有GC不误删新live/pins/shared digest。C2不物理purge。
- Source DisplayName column/scan/create/read/update；display omit keep/empty clear，config omit 保留原始 token/secret/payload/sample，metadata patch 不消除 dangling targets、不改 cron facts；CAS与边投影原子。
- Node immutable name，root/config 共享 node_configs counter；Namespace root/config 共享 namespaces counter。更新不覆盖 applied/local/token/机器 facts。
- Playbook current identity-bound CAS；原12-cell/install/dryRun/历史回执行为与195测试保留。

## 改动文件（25）
- internal/store/capability.go
- internal/store/config.go
- internal/store/deployment.go
- internal/store/migrate.go
- internal/store/namespace.go
- internal/store/node.go
- internal/store/playbook.go
- internal/store/playbook_tx.go
- internal/store/ref.go
- internal/store/resource_cas.go
- internal/store/resource_version.go
- internal/store/schema.sql
- internal/store/source.go
- internal/store/v4test/capability_spec_test.go
- internal/store/v4test/capability_test.go
- internal/store/v4test/cluster_node_test.go
- internal/store/v4test/edges_test.go
- internal/store/v4test/event_test.go
- internal/store/v4test/format_test.go
- internal/store/v4test/namespace_test.go
- internal/store/v4test/playbook_history_test.go
- internal/store/v4test/playbook_test.go
- internal/store/v4test/resource_cas_test.go
- internal/store/v4test/schema_baseline_test.go
- internal/store/v4test/source_test.go

## 测试覆盖
Original test names: 195; current: 216; original missing: none;新增21（其中原有dirty红测6，当前writer新增15）。无skip/弱化断言，edges/event_test仅精确CAS参数适配。
- TestFormatCapabilityLiveUniquePredicate
- TestFormatCapabilityMissingTombstoneAndFullUniqueRejected
- TestFormatSourceDisplayNameRequired
- TestResourceCASCapabilityConcurrentAndProjectionRollback
- TestResourceCASCapabilityDeletePinsAndRecreate
- TestResourceCASCapabilityDeleteUpdateLinearization
- TestResourceCASConcurrentCreateAndDeleteRecreate
- TestResourceCASCreateCannotMutateExisting
- TestResourceCASNamespaceRootConfigRaceAndABA
- TestResourceCASNodeRootConfigRaceAndABA
- TestResourceCASNodeRootReadsConfigToken
- TestResourceCASPinnedTaskUsesOldSpecAfterRecreate
- TestResourceCASPlaybookRecreateABAAndRace
- TestResourceCASSourceConcurrentProjection
- TestResourceCASSourceDeleteRecreateABA
- TestResourceCASSourceDisplayKeepsCronFacts
- TestResourceCASSourceDisplayNameRoundTrip
- TestResourceCASSourceDisplayOnlyAndProjectionRollback
- TestResourceCASSourceMetadataKeepsDeletedTargetIntent
- TestResourceCASSourceMissingAndStale
- TestResourceCASTokenValidation

## ACTUAL public method signatures
G3 HTTP必须用opaque expectedVersion entries，禁止先Get/check UID再无条件name写。Resource row ResourceVersion仍是内部int64 counter，公共metadata需用唯一ResourceVersion(uid,counter) helper。Immutable-ID revision methods仅供trusted内部调用。SourcePatch: DisplayName *string; Config []byte; Targets *[]sourcespec.Target; Enabled *bool。CapabilityPatch: DisplayName *string; Next *[]string。NodePatch: Tags/Namespaces *[]string; Vars map[string]string; Limits map[string]any。
```go
internal/store/capability.go: func (d *DB) UpdateNext(ctx context.Context, namespaceID, name string, version int, next []string, expectedVersion string) (*CapabilityVersion, error)
internal/store/capability.go: func (d *DB) SetCapabilityDisplayName(ctx context.Context, namespaceID, id, displayName string, expectedRV int64) error
internal/store/config.go: func (d *DB) PutNamespaceConfig(ctx context.Context, namespaceID string, vars map[string]string, rv int64) (*NamespaceConfig, error)
internal/store/config.go: func (d *DB) PutNodeConfig(ctx context.Context, cfg *NodeConfig) error
internal/store/config.go: func (d *DB) PutNodeConfigBatch(ctx context.Context, cfgs []*NodeConfig) []NodeConfigFailure
internal/store/namespace.go: func (d *DB) RenameNamespace(ctx context.Context, id, name string, expectedRV int64) error
internal/store/namespace.go: func (d *DB) DeleteNamespace(ctx context.Context, id string, force bool, expectedRV int64) error
internal/store/node.go: func (d *DB) DeleteNode(ctx context.Context, nodeID string, expectedRV int64) error
internal/store/playbook.go: func (d *DB) ReplacePlaybook(ctx context.Context, namespaceID, slug string, expectedVersion string, files map[string]string, source string) (*PlaybookRow, error)
internal/store/playbook.go: func (d *DB) DeletePlaybook(ctx context.Context, namespaceID, slug string, expectedVersion string) (*PlaybookDeleteResult, error)
internal/store/resource_cas.go: func (d *DB) UpdateCapability(ctx context.Context, namespaceID, name string, version int, patch CapabilityPatch, expectedVersion string) (*CapabilityVersion, error)
internal/store/resource_cas.go: func (d *DB) DeleteCapability(ctx context.Context, namespaceID, name, expectedVersion string) error
internal/store/resource_cas.go: func (d *DB) UpdateSourceByName(ctx context.Context, namespaceID, name string, patch SourcePatch, expectedVersion string) (*Source, error)
internal/store/resource_cas.go: func (d *DB) DeleteSourceByName(ctx context.Context, namespaceID, name, expectedVersion string) error
internal/store/resource_cas.go: func (d *DB) UpdateNode(ctx context.Context, name string, patch NodePatch, expectedVersion string) (*Node, error)
internal/store/resource_cas.go: func (d *DB) PutNodeConfigByName(ctx context.Context, name string, cfg *NodeConfig, expectedVersion string) error
internal/store/resource_cas.go: func (d *DB) DeleteNodeByName(ctx context.Context, name, expectedVersion string) error
internal/store/resource_cas.go: func (d *DB) UpdateNamespace(ctx context.Context, slug, displayName, expectedVersion string) (*Namespace, error)
internal/store/resource_cas.go: func (d *DB) DeleteNamespaceByName(ctx context.Context, slug string, force bool, expectedVersion string) error
internal/store/resource_cas.go: func (d *DB) PutNamespaceConfigByName(ctx context.Context, slug string, vars map[string]string, expectedVersion string) (*NamespaceConfig, error)
internal/store/resource_version.go: func ResourceVersion(uid string, revision int64) string
internal/store/source.go: func (d *DB) UpdateSource(ctx context.Context, s *Source) error
internal/store/source.go: func (d *DB) DeleteSource(ctx context.Context, namespaceID, id string, expectedRV int64) error
```

## MR 链接
未创建：任务明确 NO PUSH/MERGE/MR；仅本地提交等待父审查。

## 未决问题 / 下一步
- C3：actual Task/attempt/manifest/installed_from/deployment reference closure + FK/事务ref guard + tombstone安全物理GC；本轮不声称物理清理完成。
- 原 in-package tests（例如 upgrade_gate_test.go 的退役 CreateCapabilityForce）和旧 API/系统上层 CAS 调用编译适配仍属后续 C3/G2/G3/G4。本轮未改旧in-package/auth/protocol/API，不跑全仓Go/contract/e2e，不宣称全仓通过。
- G2 pinned execution/授权调用 + G3公共Status/helper/DTO映射 + G4系统/脚本/全量门禁仍待父编排。
- 工具列表没有 pi-lens：用批量read与完整逐文件diff核查；项目固定 gofmt/build/vet/test 门禁为实际自验依据。

## 最终四条固定门禁（原样输出；每条timeout60）

```text
+ timeout 60 bash -c 'test -z "$(gofmt -l internal/store)"'
EXIT=0
```

```text
+ env GOPROXY=direct GOSUMDB=sum.golang.org GOTOOLCHAIN=auto timeout 60 go build ./internal/store/
EXIT=0
```

```text
+ env GOPROXY=direct GOSUMDB=sum.golang.org GOTOOLCHAIN=auto timeout 60 go vet ./internal/store/v4test/
EXIT=0
```

```text
+ env GOPROXY=direct GOSUMDB=sum.golang.org GOTOOLCHAIN=auto timeout 60 go test ./internal/store/v4test/ -count=1
ok  	github.com/zzjcool/anotify/internal/store/v4test	23.299s
EXIT=0
```

## 原6红测 → 绿（原始输出，不改旧证据）

### /tmp/anotify-core-recovery-c2-red.log
```text
+ env GOPROXY=direct GOSUMDB=sum.golang.org GOTOOLCHAIN=auto timeout 60 go test ./internal/store/v4test/ -run 'TestResourceCAS|TestFormatSourceDisplayNameRequired' -count=1 -v
=== RUN   TestFormatSourceDisplayNameRequired
    format_test.go:1043: fresh v4 sources is missing required display_name
--- FAIL: TestFormatSourceDisplayNameRequired (0.02s)
=== RUN   TestResourceCASSourceConcurrentProjection
    resource_cas_test.go:35: same old RV: success=2 conflict=0; want 1/1
--- FAIL: TestResourceCASSourceConcurrentProjection (0.02s)
=== RUN   TestResourceCASSourceMissingAndStale
    resource_cas_test.go:46: missing RV: <nil>
--- FAIL: TestResourceCASSourceMissingAndStale (0.02s)
=== RUN   TestResourceCASCreateCannotMutateExisting
    resource_cas_test.go:58: POST reuse mutated existing resource without CAS: &{ID:cap_1794264643_b55cffed_FyDstRa NamespaceID:ns_BCHoBgNQTQzAoZyUQl Name:review DisplayName:unguarded Version:1 Digest:sha256:b55cffedfb1a1d399c088b376c9eaeb53e908de84970bb998509bfe0c7632ef0 FoldKey:sha256:68c04fa6131d237c7dda834c9053e5fb42159259d9578571cad2d6a15b910049 InstalledFrom: ResourceVersion:3 CreatedAt:1794264643 Spec:{Params:[123 34 116 121 112 101 34 58 34 111 98 106 101 99 116 34 125] Next:[after] Run:{Entrypoint:run.sh Files:map[run.sh:#!/bin/sh
        exit 0
        ] Env:map[] WorkDir:} Requires:{Commands:[] Values:[]} Lifecycle:{Idempotent:false MaxAttempts:0xc00038f7b0 ResultTTLSec:0xc00038f7b8 TimeoutSec:0} Concurrency:{MaxPerNode:0xc00038f7e0}}}
--- FAIL: TestResourceCASCreateCannotMutateExisting (0.02s)
=== RUN   TestResourceCASSourceDisplayNameRoundTrip
    resource_cas_test.go:73: displayName lost through create/reopen: {"id":"src_BCHoBgTYXUYPly3HuG","namespaceId":"ns_BCHoBgTbYYnbmCrzSb","name":"hook","kind":"webhook","config":{"token":"src_fixed","secret":"secret","sample":{"message":"keep"}},"targets":[],"enabled":true,"lastFiredAt":null,"nextFireAt":null,"installedFrom":"","resourceVersion":1,"createdAt":1794264643}
--- FAIL: TestResourceCASSourceDisplayNameRoundTrip (0.06s)
=== RUN   TestResourceCASNodeRootReadsConfigToken
    resource_cas_test.go:81: node RV=1 config RV=2; root/config bypass
--- FAIL: TestResourceCASNodeRootReadsConfigToken (0.02s)
FAIL
FAIL	github.com/zzjcool/anotify/internal/store/v4test	0.161s
FAIL
EXIT=1
```

### /tmp/anotify-core-recovery-c2-green2.log
```text
+ env GOPROXY=direct GOSUMDB=sum.golang.org GOTOOLCHAIN=auto timeout 60 go test ./internal/store/v4test/ -run 'TestResourceCAS|TestFormatSourceDisplayNameRequired|TestFormatCapability' -count=1 -v
=== RUN   TestFormatSourceDisplayNameRequired
--- PASS: TestFormatSourceDisplayNameRequired (0.06s)
=== RUN   TestFormatCapabilityLiveUniquePredicate
=== RUN   TestFormatCapabilityLiveUniquePredicate/baseline
=== RUN   TestFormatCapabilityLiveUniquePredicate/whole
=== RUN   TestFormatCapabilityLiveUniquePredicate/identifier
=== RUN   TestFormatCapabilityLiveUniquePredicate/opposite
=== RUN   TestFormatCapabilityLiveUniquePredicate/operandGroup
=== RUN   TestFormatCapabilityLiveUniquePredicate/operandNullGroup
=== RUN   TestFormatCapabilityLiveUniquePredicate/expression
=== RUN   TestFormatCapabilityLiveUniquePredicate/extra
=== RUN   TestFormatCapabilityLiveUniquePredicate/literal
--- PASS: TestFormatCapabilityLiveUniquePredicate (0.48s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/baseline (0.05s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/whole (0.06s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/identifier (0.04s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/opposite (0.08s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/operandGroup (0.04s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/operandNullGroup (0.04s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/expression (0.06s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/extra (0.07s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/literal (0.04s)
=== RUN   TestFormatCapabilityMissingTombstoneAndFullUniqueRejected
=== RUN   TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/missing-column
=== RUN   TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/full-only
=== RUN   TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/active-plus-full
=== RUN   TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/extra-key
--- PASS: TestFormatCapabilityMissingTombstoneAndFullUniqueRejected (0.16s)
    --- PASS: TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/missing-column (0.04s)
    --- PASS: TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/full-only (0.04s)
    --- PASS: TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/active-plus-full (0.04s)
    --- PASS: TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/extra-key (0.04s)
=== RUN   TestResourceCASSourceConcurrentProjection
--- PASS: TestResourceCASSourceConcurrentProjection (0.02s)
=== RUN   TestResourceCASSourceMissingAndStale
--- PASS: TestResourceCASSourceMissingAndStale (0.02s)
=== RUN   TestResourceCASCreateCannotMutateExisting
--- PASS: TestResourceCASCreateCannotMutateExisting (0.02s)
=== RUN   TestResourceCASSourceDisplayNameRoundTrip
--- PASS: TestResourceCASSourceDisplayNameRoundTrip (0.03s)
=== RUN   TestResourceCASNodeRootReadsConfigToken
--- PASS: TestResourceCASNodeRootReadsConfigToken (0.02s)
=== RUN   TestResourceCASCapabilityDeletePinsAndRecreate
--- PASS: TestResourceCASCapabilityDeletePinsAndRecreate (0.02s)
=== RUN   TestResourceCASCapabilityConcurrentAndProjectionRollback
--- PASS: TestResourceCASCapabilityConcurrentAndProjectionRollback (0.02s)
=== RUN   TestResourceCASCapabilityDeleteUpdateLinearization
--- PASS: TestResourceCASCapabilityDeleteUpdateLinearization (0.02s)
=== RUN   TestResourceCASSourceDisplayOnlyAndProjectionRollback
--- PASS: TestResourceCASSourceDisplayOnlyAndProjectionRollback (0.02s)
=== RUN   TestResourceCASSourceDeleteRecreateABA
--- PASS: TestResourceCASSourceDeleteRecreateABA (0.02s)
=== RUN   TestResourceCASNodeRootConfigRaceAndABA
--- PASS: TestResourceCASNodeRootConfigRaceAndABA (0.02s)
=== RUN   TestResourceCASNamespaceRootConfigRaceAndABA
--- PASS: TestResourceCASNamespaceRootConfigRaceAndABA (0.02s)
=== RUN   TestResourceCASPlaybookRecreateABAAndRace
--- PASS: TestResourceCASPlaybookRecreateABAAndRace (0.02s)
=== RUN   TestResourceCASTokenValidation
--- PASS: TestResourceCASTokenValidation (0.02s)
=== RUN   TestResourceCASPinnedTaskUsesOldSpecAfterRecreate
--- PASS: TestResourceCASPinnedTaskUsesOldSpecAfterRecreate (0.02s)
=== RUN   TestResourceCASConcurrentCreateAndDeleteRecreate
--- PASS: TestResourceCASConcurrentCreateAndDeleteRecreate (0.02s)
PASS
ok  	github.com/zzjcool/anotify/internal/store/v4test	1.025s
EXIT=0
```

## 额外产品缺口红绿 / 保留失败输出
配置省略丢sample，dangling target metadata修改被拒，额外全表DESC unique阻止recreate，display修改重置cron schedule事实；均在授权范围测试抓住并修复。green1中另一个Namespace失败是新增fixture只建了一个namespace，补保留ns而不改最后namespace保护断言。

### /tmp/anotify-core-recovery-c2-green1.log
```text
+ env GOPROXY=direct GOSUMDB=sum.golang.org GOTOOLCHAIN=auto timeout 60 go test ./internal/store/v4test/ -run 'TestResourceCAS|TestFormatSourceDisplayNameRequired|TestFormatCapability' -count=1 -v
=== RUN   TestFormatSourceDisplayNameRequired
--- PASS: TestFormatSourceDisplayNameRequired (0.05s)
=== RUN   TestFormatCapabilityLiveUniquePredicate
=== RUN   TestFormatCapabilityLiveUniquePredicate/baseline
=== RUN   TestFormatCapabilityLiveUniquePredicate/whole
=== RUN   TestFormatCapabilityLiveUniquePredicate/identifier
=== RUN   TestFormatCapabilityLiveUniquePredicate/opposite
=== RUN   TestFormatCapabilityLiveUniquePredicate/operandGroup
=== RUN   TestFormatCapabilityLiveUniquePredicate/operandNullGroup
=== RUN   TestFormatCapabilityLiveUniquePredicate/expression
=== RUN   TestFormatCapabilityLiveUniquePredicate/extra
=== RUN   TestFormatCapabilityLiveUniquePredicate/literal
--- PASS: TestFormatCapabilityLiveUniquePredicate (0.40s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/baseline (0.07s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/whole (0.04s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/identifier (0.04s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/opposite (0.04s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/operandGroup (0.04s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/operandNullGroup (0.04s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/expression (0.05s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/extra (0.05s)
    --- PASS: TestFormatCapabilityLiveUniquePredicate/literal (0.04s)
=== RUN   TestFormatCapabilityMissingTombstoneAndFullUniqueRejected
=== RUN   TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/missing-column
=== RUN   TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/full-only
=== RUN   TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/active-plus-full
=== RUN   TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/extra-key
--- PASS: TestFormatCapabilityMissingTombstoneAndFullUniqueRejected (0.19s)
    --- PASS: TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/missing-column (0.05s)
    --- PASS: TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/full-only (0.04s)
    --- PASS: TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/active-plus-full (0.04s)
    --- PASS: TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/extra-key (0.06s)
=== RUN   TestResourceCASSourceConcurrentProjection
--- PASS: TestResourceCASSourceConcurrentProjection (0.03s)
=== RUN   TestResourceCASSourceMissingAndStale
--- PASS: TestResourceCASSourceMissingAndStale (0.02s)
=== RUN   TestResourceCASCreateCannotMutateExisting
--- PASS: TestResourceCASCreateCannotMutateExisting (0.02s)
=== RUN   TestResourceCASSourceDisplayNameRoundTrip
--- PASS: TestResourceCASSourceDisplayNameRoundTrip (0.03s)
=== RUN   TestResourceCASNodeRootReadsConfigToken
--- PASS: TestResourceCASNodeRootReadsConfigToken (0.03s)
=== RUN   TestResourceCASCapabilityDeletePinsAndRecreate
--- PASS: TestResourceCASCapabilityDeletePinsAndRecreate (0.03s)
=== RUN   TestResourceCASCapabilityConcurrentAndProjectionRollback
--- PASS: TestResourceCASCapabilityConcurrentAndProjectionRollback (0.02s)
=== RUN   TestResourceCASCapabilityDeleteUpdateLinearization
--- PASS: TestResourceCASCapabilityDeleteUpdateLinearization (0.02s)
=== RUN   TestResourceCASSourceDisplayOnlyAndProjectionRollback
    resource_cas_test.go:367: display touched spec/credentials: &{ID:src_BCHsWBnB4MmOG7n6ka NamespaceID:ns_BCHsWBmyuvl814MRBT DisplayName:changed Name:hook Kind:webhook Config:[123 34 116 111 107 101 110 34 58 34 115 114 99 95 102 105 120 101 100 34 44 34 115 101 99 114 101 116 34 58 34 115 101 99 114 101 116 34 125] Targets:[{Capability:worker Params:map[]}] Enabled:true LastFiredAt:<nil> NextFireAt:<nil> InstalledFrom: ResourceVersion:2 CreatedAt:1794267554}
--- FAIL: TestResourceCASSourceDisplayOnlyAndProjectionRollback (0.02s)
=== RUN   TestResourceCASSourceDeleteRecreateABA
--- PASS: TestResourceCASSourceDeleteRecreateABA (0.02s)
=== RUN   TestResourceCASNodeRootConfigRaceAndABA
--- PASS: TestResourceCASNodeRootConfigRaceAndABA (0.02s)
=== RUN   TestResourceCASNamespaceRootConfigRaceAndABA
    resource_cas_test.go:487: store: cannot delete the last namespace of the deployment
--- FAIL: TestResourceCASNamespaceRootConfigRaceAndABA (0.02s)
=== RUN   TestResourceCASPlaybookRecreateABAAndRace
--- PASS: TestResourceCASPlaybookRecreateABAAndRace (0.02s)
=== RUN   TestResourceCASTokenValidation
--- PASS: TestResourceCASTokenValidation (0.02s)
FAIL
FAIL	github.com/zzjcool/anotify/internal/store/v4test	0.948s
FAIL
EXIT=1
```

### /tmp/anotify-core-recovery-c2-dangling-red.log
```text
+ env GOPROXY=direct GOSUMDB=sum.golang.org GOTOOLCHAIN=auto timeout 60 go test ./internal/store/v4test/ -run TestResourceCASSourceMetadataKeepsDeletedTargetIntent -count=1 -v
=== RUN   TestResourceCASSourceMetadataKeepsDeletedTargetIntent
    resource_cas_test.go:648: metadata mutation must keep incoming missing intent: 出口能力 worker@1 不存在
--- FAIL: TestResourceCASSourceMetadataKeepsDeletedTargetIntent (0.02s)
FAIL
FAIL	github.com/zzjcool/anotify/internal/store/v4test	0.023s
FAIL
EXIT=1
```

### /tmp/anotify-core-recovery-c2-dangling-green.log
```text
+ env GOPROXY=direct GOSUMDB=sum.golang.org GOTOOLCHAIN=auto timeout 60 go test ./internal/store/v4test/ -run TestResourceCASSourceMetadataKeepsDeletedTargetIntent -count=1 -v
=== RUN   TestResourceCASSourceMetadataKeepsDeletedTargetIntent
--- PASS: TestResourceCASSourceMetadataKeepsDeletedTargetIntent (0.02s)
PASS
ok  	github.com/zzjcool/anotify/internal/store/v4test	0.025s
EXIT=0
```

### /tmp/anotify-core-recovery-c2-full-key-red.log
```text
+ env GOPROXY=direct GOSUMDB=sum.golang.org GOTOOLCHAIN=auto timeout 60 go test ./internal/store/v4test/ -run TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/active-plus-full-desc -count=1 -v
=== RUN   TestFormatCapabilityMissingTombstoneAndFullUniqueRejected
=== RUN   TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/active-plus-full-desc
    format_test.go:1153: bad capability layout accepted: <nil>
--- FAIL: TestFormatCapabilityMissingTombstoneAndFullUniqueRejected (0.06s)
    --- FAIL: TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/active-plus-full-desc (0.06s)
FAIL
FAIL	github.com/zzjcool/anotify/internal/store/v4test	0.067s
FAIL
EXIT=1
```

### /tmp/anotify-core-recovery-c2-full-key-green.log
```text
+ env GOPROXY=direct GOSUMDB=sum.golang.org GOTOOLCHAIN=auto timeout 60 go test ./internal/store/v4test/ -run TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/active-plus-full-desc -count=1 -v
=== RUN   TestFormatCapabilityMissingTombstoneAndFullUniqueRejected
=== RUN   TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/active-plus-full-desc
--- PASS: TestFormatCapabilityMissingTombstoneAndFullUniqueRejected (0.05s)
    --- PASS: TestFormatCapabilityMissingTombstoneAndFullUniqueRejected/active-plus-full-desc (0.05s)
PASS
ok  	github.com/zzjcool/anotify/internal/store/v4test	0.057s
EXIT=0
```

### /tmp/anotify-core-recovery-c2-cron-red.log
```text
+ env GOPROXY=direct GOSUMDB=sum.golang.org GOTOOLCHAIN=auto timeout 60 go test ./internal/store/v4test/ -run TestResourceCASSourceDisplayKeepsCronFacts -count=1 -v
=== RUN   TestResourceCASSourceDisplayKeepsCronFacts
    resource_cas_test.go:674: display-only rewrote cron facts: before=&{ID:src_BCHtUk2Nuo27kttNd9 NamespaceID:ns_BCHtUk2FFaCzzSraQA DisplayName: Name:clock Kind:cron Config:[123 34 101 120 112 114 34 58 34 48 32 54 32 42 32 42 32 42 34 44 34 116 122 34 58 34 76 111 99 97 108 34 125] Targets:[] Enabled:true LastFiredAt:0xc0002c6158 NextFireAt:0xc0002c6160 InstalledFrom: ResourceVersion:1 CreatedAt:1794268211} after=&{ID:src_BCHtUk2Nuo27kttNd9 NamespaceID:ns_BCHtUk2FFaCzzSraQA DisplayName:display only Name:clock Kind:cron Config:[123 34 101 120 112 114 34 58 34 48 32 54 32 42 32 42 32 42 34 44 34 116 122 34 58 34 76 111 99 97 108 34 125] Targets:[] Enabled:true LastFiredAt:0xc0002c6298 NextFireAt:0xc0002c62e0 InstalledFrom: ResourceVersion:2 CreatedAt:1794268211}
--- FAIL: TestResourceCASSourceDisplayKeepsCronFacts (0.03s)
FAIL
FAIL	github.com/zzjcool/anotify/internal/store/v4test	0.036s
FAIL
EXIT=1
```

### /tmp/anotify-core-recovery-c2-cron-green.log
```text
+ env GOPROXY=direct GOSUMDB=sum.golang.org GOTOOLCHAIN=auto timeout 60 go test ./internal/store/v4test/ -run TestResourceCASSourceDisplayKeepsCronFacts -count=1 -v
=== RUN   TestResourceCASSourceDisplayKeepsCronFacts
--- PASS: TestResourceCASSourceDisplayKeepsCronFacts (0.02s)
PASS
ok  	github.com/zzjcool/anotify/internal/store/v4test	0.026s
EXIT=0
```
